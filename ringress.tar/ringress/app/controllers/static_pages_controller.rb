class StaticPagesController < ApplicationController
  def portal_mitigation
  end
end
