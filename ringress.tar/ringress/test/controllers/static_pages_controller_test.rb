require 'test_helper'

class StaticPagesControllerTest < ActionController::TestCase
  test "should get portal_mitigation" do
    get :portal_mitigation
    assert_response :success
  end

end
